# Description

## FishFix is a mod that fixes the issues with picking up fish on the PTB. Will remove when fixed in the base game.


`ONLY WORKS ON THE PTB (Mistlands)`

---

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***

> # Update Information (Latest listed first)
> ### v1.0.1
> - Fixed the vanilla "bug" with the stack size. They forced the stack of the fish to be 1, regardless of the fact the stack was 8 while in your inventory. If you dropped the item you'd only get 1 fish back no matter what. This is now fixed.
> ### v1.0.0
> - Initial Release